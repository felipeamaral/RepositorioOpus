﻿using System.Web;
using System.Web.Optimization;

namespace materialDesign
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js",
                        "~/Scripts/materialize/materialize.js"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/Site.css"));

            bundles.Add(new ScriptBundle("~/bundles/angular").Include(
                      "~/Scripts/angular/angular.min.js",
                      "~/Scripts/angular/angular-ui-router.js",
                      "~/Scripts/angular/angular-animate.min.js",
                      "~/Scripts/angular/angular-aria.min.js",
                      "~/Scripts/angular/angular-material.min.js",
                      "~/Scripts/angular/angular-material-icons.min.js",
                      "~/Scripts/angular/svg-morpheus.js"));

            bundles.Add(new ScriptBundle("~/bundles/app").Include(
                      "~/app/app.js"));

            bundles.Add(new ScriptBundle("~/bundles/appConfig").Include(
                      "~/app/appConfig.js"));

            bundles.Add(new ScriptBundle("~/bundles/appControllers").Include(
                      "~/app/controllers/appCtrl.js",
                      "~/app/controllers/LeftCtrl.js"));


            // Set EnableOptimizations to false for debugging. For more information,
            // visit http://go.microsoft.com/fwlink/?LinkId=301862
            BundleTable.EnableOptimizations = true;
        }
    }
}
