﻿'use strict';

app.config(['$stateProvider', '$urlRouterProvider', '$locationProvider', '$httpProvider',
    function ($stateProvider, $urlRouterProvider, $locationProvider, $httpProvider) {

    // Unmatched url
    $urlRouterProvider.otherwise('/Home');

    // States
    $stateProvider
        .state('home', {
            url: "/Home",
            templateUrl: "app/templates/Home.html",
        });
}]);