﻿'use strict';

app.config(function ($stateProvider, $urlRouterProvider, $locationProvider, $httpProvider) {

    // States
    $stateProvider
        .state('home', {
            url: "/Home",
            templateUrl: "app/templates/Home.html",
        });

    // Unmatched url
    $urlRouterProvider.otherwise('/Home');
});