﻿app.controller('LeftCtrl', ['$scope', '$state', '$mdDialog', function ($scope, $state, $mdDialog) {

    //Controla o icone das opções primarias do menu

}]);