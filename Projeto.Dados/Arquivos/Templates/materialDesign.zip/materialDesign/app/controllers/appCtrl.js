﻿app.controller('appCtrl', ['$scope', '$mdSidenav', '$mdUtil', '$log', '$state', function ($scope, $mdSidenav, $mdUtil, $log, $state) {

    $scope.toggleLeft = buildToggler('left');
    $scope.iconMenu = "menu";
    $scope.placeholder = "placeholder busca";

    // Escuta se a barra lateral está aberta
    $scope.$watch(
        function () {
            return $mdSidenav('left').isOpen();
        },
        function (newValue, oldValue) {
            if (newValue == false) {
                $scope.iconMenu = "menu";
            }
        }
    );

    // Muda o ícone do menu, conforme o mesmo é aberto e fechado
    $scope.changeIcon = function () {
        if ($scope.iconMenu === "menu") {
            $scope.iconMenu = "arrow_back";
        } else {
            $scope.iconMenu = "menu";
        }

        $scope.toggleLeft();
    };

    //Função que abre o menu lateral
    function buildToggler(navID) {

        var debounceFn = $mdUtil.debounce(function () {
            $mdSidenav(navID)
              .toggle()
              .then(function () {
                  $log.debug("toggle " + navID + " is done");
              });
        }, 1);

        return debounceFn;
    }

    // Faz a busca quando é pressionada a tecla enter na caixa de busca
    $scope.keyPress = function (event) {
        if (event.which === 13) {
            // Realiza funções relacionadas a busca
        }
    }

    // Esconde a barra de busca
    $scope.closeSearch = function () {
        $("#searchToolBar").addClass("hidden");
        $("#menuToolBar").removeClass("hidden");
    };

    // Abre a barra de busca
    $scope.openSearch = function () {
        $("#menuToolBar").addClass("hidden");
        $("#searchToolBar").removeClass("hidden");
    };

    // Vai pra tela de home
    $scope.home = function () {
        $state.go('home');
    };

}]);