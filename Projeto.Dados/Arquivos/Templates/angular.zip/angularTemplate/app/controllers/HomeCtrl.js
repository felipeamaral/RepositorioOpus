﻿'use strict';

app.controller('HomeCtrl', function ($scope) {
});