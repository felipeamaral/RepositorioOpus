﻿'use strict';

app.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {

    // States
    $stateProvider
        .state('home', {
            url: "/Home",
            templateUrl: "app/templates/Home.html",
            controller: 'HomeCtrl',
        })

    // Unmatched url
    $urlRouterProvider.otherwise('/Home');
}]);