function another(){
  console.log("Another with code!");  
};